import java.util.ArrayList;

public class MarinaAlbufeira {
    private ArrayList<Barco> barcos;

    public MarinaAlbufeira(ArrayList<Barco> barcos) {
        this.barcos = barcos;
    }

    public void remBarco() {

    }

    public ArrayList<Barco> getBarcos() {
        return barcos;
    }

    public void setBarcos(ArrayList<Barco> barcos) {
        this.barcos = barcos;
    }
}